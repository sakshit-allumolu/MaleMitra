# MaleMitra (ಮಳೆ ಮಿತ್ರ) — IBM Bobathon: Build for Bengaluru 2026

Theme: Smarter Streets, Better Living

| Phase 1 deliverable | Folder |
|---|---|
| 1. Problem statement and detailed solution description | `01_Problem_Statement_and_Solution/` |
| 2. A working solution built with IBM Bob | `02_Working_Solution_Built_with_IBM_Bob/` (how to run it, Bob and watsonx Orchestrate, tests, screenshots) |
| 3. Source code repository | `03_Source_Code_Repository/` (full code) and https://github.com/sakshit-allumolu/MaleMitra (branch `feature-demo`) |
| 4. Presentation deck | `04_Presentation_Deck/IBM_Bobathon_Presentation.pptx` |
| 5. Video demonstration | `05_Video_Demonstration/VIDEO_LINK.txt` |

Quick run (details in `02_Working_Solution_Built_with_IBM_Bob/How_to_Run_It.md`):

```bash
cd 03_Source_Code_Repository
python3 -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements-dev.txt
pytest backend/tests          # 242 passed on 15 Nov 2026
```
