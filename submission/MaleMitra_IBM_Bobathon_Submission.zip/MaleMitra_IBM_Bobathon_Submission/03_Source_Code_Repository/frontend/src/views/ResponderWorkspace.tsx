import React, { useState, useEffect } from 'react';
import { useIncidents } from '../context/IncidentContext';
import { useAuth } from '../context/AuthContext';
import { ApiClient } from '../services/api';
import { StatusBadge } from '../components/StatusBadge';
import { Incident } from '../types';
import { InteractiveMap } from '../components/InteractiveMap';
import {
  Users, CheckCircle2, AlertTriangle, Send, MapPin,
  Camera, Droplets, ShieldAlert, Check, RefreshCw,
  Navigation, Route, Clock, ShieldCheck
} from 'lucide-react';

export const ResponderWorkspace: React.FC = () => {
  const { incidents, refreshData, setHighlightedCoordinates, calculateRoutes, selectedRoute, setRoutesResult } = useIncidents();
  const { currentUser } = useAuth();

  const [responderLocation, setResponderLocation] = useState<{ lat: number; lon: number }>({ lat: 12.942, lon: 77.628 });
  const [isFindingRoute, setIsFindingRoute] = useState<boolean>(false);

  const [tab, setTab] = useState<'mine' | 'queue'>('mine');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [claiming, setClaiming] = useState<boolean>(false);

  // Field Verification Form State
  const [waterDepth, setWaterDepth] = useState<number>(55);
  const [isImpassable, setIsImpassable] = useState<boolean>(true);
  const [findings, setFindings] = useState<string>('On-site inspection confirms deep standing water across both lanes. Vehicles stalling.');
  const [recommendedAction, setRecommendedAction] = useState<string>('authorize_closure');
  const [evidenceNote, setEvidenceNote] = useState<string>('Staff gauge reading 55cm at underpass entrance.');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Clearance Form State
  const [clearanceFindings, setClearanceFindings] = useState<string>('Dewatering pumps operated for 2 hours. Storm grates cleared of silt. Water depth below 5cm.');

  const teamId = currentUser.team_id || 'team-alpha';
  const open = incidents.filter(i => i.assigned_team_id === teamId && !['cleared', 'rejected'].includes(i.status));
  // "My tasks" are assigned to me personally; the "Team queue" is the team's unclaimed work.
  const myTasks = open.filter(i => i.assigned_responder_id === currentUser.id);
  const queue = open.filter(i => !i.assigned_responder_id && i.status === 'assigned');
  // Responder is free if they don't have an active unverified assignment or uncompleted dewatering
  const activeTasks = myTasks.filter(i => i.status === 'assigned' || i.status === 'blocked');
  const isFree = activeTasks.length === 0;
  const visible = tab === 'mine' ? myTasks : queue;
  const selectedTask = [...myTasks, ...queue].find(i => i.id === selectedId) || null;
  const selectedIsMine = !!selectedTask && selectedTask.assigned_responder_id === currentUser.id;

  // Get live responder location on mount & watch
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setResponderLocation({
            lat: pos.coords.latitude,
            lon: pos.coords.longitude,
          });
        },
        () => {},
        { enableHighAccuracy: true, timeout: 5000 }
      );
    }
  }, []);

  useEffect(() => {
    // Keep a sensible selection when the lists change (new assignment, task claimed, etc.)
    if (!selectedTask && visible.length > 0) {
      setSelectedId(visible[0].id);
      setHighlightedCoordinates([visible[0].lat, visible[0].lon]);
      setRoutesResult(null);
    }
  }, [incidents, tab, currentUser]);

  const handleSelectTask = (task: Incident) => {
    setSelectedId(task.id);
    setHighlightedCoordinates([task.lat, task.lon]);
    setRoutesResult(null);
  };

  const handleFindRoute = async () => {
    if (!selectedTask) return;
    setIsFindingRoute(true);
    try {
      await calculateRoutes(
        responderLocation,
        { lat: selectedTask.lat, lon: selectedTask.lon }
      );
    } catch (err: any) {
      alert(`Route error: ${err.message || 'Failed to calculate route'}`);
    } finally {
      setIsFindingRoute(false);
    }
  };

  const handleClaim = async (task: Incident) => {
    setClaiming(true);
    try {
      await ApiClient.claimIncident(task.id);
      await refreshData();
      setTab('mine');
      setSelectedId(task.id);
    } catch (err: any) {
      alert(err.message);
    } finally {
      setClaiming(false);
    }
  };

  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask) return;
    setIsSubmitting(true);
    setSuccessMsg(null);
    try {
      await ApiClient.verifyIncident(selectedTask.id, {
        findings,
        water_depth_cm: waterDepth,
        is_impassable: isImpassable,
        recommended_action: recommendedAction,
        evidence_note: evidenceNote
      });
      setSuccessMsg('Field verification submitted! Sent to Control Room for road closure authorization.');
      await refreshData();
    } catch (err: any) {
      alert(`Verification error: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClearanceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask) return;
    setIsSubmitting(true);
    setSuccessMsg(null);
    try {
      await ApiClient.proposeClearance(selectedTask.id, clearanceFindings, 'Field inspection confirms drain clearance complete.');
      setSuccessMsg('Clearance proposal submitted! Control Room notified to authorize reopening.');
      await refreshData();
    } catch (err: any) {
      alert(`Clearance error: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div style={{ width: '100%', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Header Banner */}
      <div style={{
        backgroundColor: '#123047',
        color: '#FFFFFF',
        borderRadius: '10px',
        padding: '18px 24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '12px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '42px',
            height: '42px',
            borderRadius: '8px',
            backgroundColor: '#0B8B95',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <Users size={24} color="#FFF" />
          </div>
          <div>
            <h2 style={{ fontSize: '18px', fontWeight: 800, margin: 0 }}>
              Field Response Workspace
            </h2>
            <p style={{ fontSize: '12px', color: '#94A3B8', margin: 0 }}>
              Responder: <strong>{currentUser.name}</strong> • Unit: <strong>{currentUser.team_id || 'Team Alpha (Stormwater)'}</strong>
              {' '}• <strong style={{ color: isFree ? '#6EE7B7' : '#FCD34D' }}>{isFree ? 'Free' : 'On a task'}</strong>
            </p>
          </div>
        </div>

        <button
          onClick={() => refreshData()}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '8px 14px',
            borderRadius: '6px',
            backgroundColor: '#0B8B95',
            color: '#FFFFFF',
            border: 'none',
            fontSize: '12px',
            fontWeight: 700,
            cursor: 'pointer'
          }}
        >
          <RefreshCw size={14} /> Refresh Assigned Tasks
        </button>
      </div>

      <div className="mm-two-col">
        {/* Left Column: Assigned Tasks List */}
        <div style={{
          backgroundColor: '#FFFFFF',
          borderRadius: '10px',
          border: '1px solid #E2E8F0',
          padding: '16px',
          boxShadow: '0 2px 6px rgba(0,0,0,0.04)',
          display: 'flex',
          flexDirection: 'column',
          gap: '10px'
        }}>
          <div style={{ display: 'flex', gap: '6px', paddingBottom: '8px', borderBottom: '1px solid #E2E8F0' }}>
            {([['mine', 'My tasks', myTasks.length], ['queue', 'Team queue', queue.length]] as const).map(([key, label, count]) => (
              <button
                key={key}
                onClick={() => { setTab(key); setSelectedId(null); }}
                style={{
                  flex: 1, padding: '7px 8px', borderRadius: '6px', fontSize: '12px', fontWeight: 800, cursor: 'pointer',
                  border: `1.5px solid ${tab === key ? '#0B8B95' : '#E2E8F0'}`,
                  backgroundColor: tab === key ? '#F0FDFA' : '#FFFFFF',
                  color: tab === key ? '#0B8B95' : '#64748B'
                }}
              >
                {label} ({count})
              </button>
            ))}
          </div>

          {visible.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '24px 0', color: '#94A3B8', fontSize: '12px' }}>
              {tab === 'mine'
                ? 'Nothing assigned to you. Standby, or take a task from the team queue.'
                : 'No unclaimed tasks for your team.'}
            </div>
          ) : (
            visible.map((task) => {
              const isSelected = selectedTask?.id === task.id;

              return (
                <div
                  key={task.id}
                  onClick={() => handleSelectTask(task)}
                  style={{
                    padding: '12px',
                    borderRadius: '8px',
                    border: `1.5px solid ${isSelected ? '#0B8B95' : '#E2E8F0'}`,
                    backgroundColor: isSelected ? '#F0FDFA' : '#FAFAFA',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '4px' }}>
                    <span style={{ fontSize: '11px', fontFamily: 'monospace', fontWeight: 700, color: '#64748B' }}>
                      {task.id}
                    </span>
                    <StatusBadge status={task.status} size="sm" />
                  </div>

                  <div style={{ fontWeight: 700, fontSize: '13px', color: '#1E293B', marginBottom: '2px' }}>
                    {task.road_name || 'Waterlogging Site'}
                  </div>

                  <div style={{ fontSize: '11px', color: '#64748B' }}>
                    📍 Coordinates: ({task.lat}, {task.lon})
                  </div>

                  {tab === 'queue' && (
                    <button
                      onClick={(e) => { e.stopPropagation(); handleClaim(task); }}
                      disabled={!isFree || claiming}
                      title={isFree ? undefined : 'Finish your current task before taking a new one.'}
                      style={{
                        marginTop: '8px', width: '100%', padding: '7px', borderRadius: '6px', border: 'none',
                        fontSize: '12px', fontWeight: 700, color: '#FFF',
                        backgroundColor: isFree && !claiming ? '#0B8B95' : '#A7B0BE',
                        cursor: isFree && !claiming ? 'pointer' : 'not-allowed'
                      }}
                    >
                      {isFree ? 'Take this task' : 'Busy — finish your task first'}
                    </button>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Right Column: Field Inspection & Verification Actions */}
        {selectedTask ? (
          <div style={{
            backgroundColor: '#FFFFFF',
            borderRadius: '10px',
            border: '1px solid #E2E8F0',
            padding: '20px',
            boxShadow: '0 2px 6px rgba(0,0,0,0.04)',
            display: 'flex',
            flexDirection: 'column',
            gap: '16px'
          }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', borderBottom: '1px solid #E2E8F0', paddingBottom: '12px' }}>
              <div>
                <span style={{ fontSize: '11px', fontWeight: 700, color: '#0B8B95', backgroundColor: '#E6FFFA', padding: '2px 6px', borderRadius: '4px' }}>
                  ACTIVE FIELD INSPECTION
                </span>
                <h3 style={{ fontSize: '17px', fontWeight: 800, color: '#1E293B', margin: '4px 0' }}>
                  {selectedTask.road_name || 'Waterlogging Hazard'}
                </h3>
                <div style={{ fontSize: '12px', color: '#64748B' }}>
                  Citizen Report: "{selectedTask.evidence_list[0]?.text_notes || 'Hazard reported'}"
                </div>
              </div>

              <StatusBadge status={selectedTask.status} size="md" />
            </div>

            {successMsg && (
              <div style={{
                padding: '10px 14px',
                backgroundColor: '#ECFDF5',
                border: '1px solid #A7F3D0',
                borderRadius: '6px',
                fontSize: '12px',
                color: '#065F46',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}>
                <CheckCircle2 size={16} color="#059669" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Live Navigation & Routing to Incident */}
            <div style={{
              backgroundColor: '#F8FAFC',
              borderRadius: '8px',
              border: '1px solid #CBD5E1',
              padding: '12px',
              display: 'flex',
              flexDirection: 'column',
              gap: '10px'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '8px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', fontWeight: 800, color: '#1E293B' }}>
                  <Navigation size={16} color="#0B8B95" />
                  <span>Live Dispatch Route to Incident</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                  {selectedRoute ? (
                    <>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '12px', fontWeight: 700 }}>
                        <span style={{ color: '#0B8B95', display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <Clock size={13} /> {Math.round(selectedRoute.estimated_duration_s / 60)} min ETA
                        </span>
                        <span style={{ color: '#64748B', display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <Route size={13} /> {(selectedRoute.distance_m / 1000).toFixed(1)} km
                        </span>
                        <span style={{
                          backgroundColor: selectedRoute.type === 'risk_aware' ? '#ECFDF5' : '#FFFBEB',
                          color: selectedRoute.type === 'risk_aware' ? '#059669' : '#D97706',
                          padding: '2px 8px',
                          borderRadius: '12px',
                          fontSize: '11px',
                          border: `1px solid ${selectedRoute.type === 'risk_aware' ? '#A7F3D0' : '#FDE68A'}`
                        }}>
                          {selectedRoute.type === 'risk_aware' ? '🛡️ Risk-Aware Detour' : '⚡ Shortest Route'}
                        </span>
                      </div>
                      <button
                        onClick={handleFindRoute}
                        disabled={isFindingRoute}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '4px',
                          padding: '5px 10px',
                          borderRadius: '6px',
                          backgroundColor: '#F1F5F9',
                          color: '#0F172A',
                          border: '1px solid #CBD5E1',
                          fontSize: '11px',
                          fontWeight: 700,
                          cursor: isFindingRoute ? 'wait' : 'pointer'
                        }}
                      >
                        <RefreshCw size={12} /> Recalculate
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={handleFindRoute}
                      disabled={isFindingRoute}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        padding: '7px 14px',
                        borderRadius: '6px',
                        backgroundColor: '#0B8B95',
                        color: '#FFFFFF',
                        border: 'none',
                        fontSize: '12px',
                        fontWeight: 700,
                        cursor: isFindingRoute ? 'wait' : 'pointer',
                        boxShadow: '0 2px 6px rgba(11, 139, 149, 0.35)',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      <Navigation size={14} />
                      {isFindingRoute ? 'Calculating Safe Detour...' : 'Find Route (Avoid Blockages)'}
                    </button>
                  )}
                </div>
              </div>

              {/* Interactive Map */}
              <InteractiveMap
                originPin={[responderLocation.lat, responderLocation.lon]}
                destPin={[selectedTask.lat, selectedTask.lon]}
                onLocationFound={(lat, lon) => setResponderLocation({ lat, lon })}
                height="480px"
                vehicleType="responder"
                pinMode="none"
              />
            </div>

            {!selectedIsMine && (
              <div style={{ padding: '10px 14px', borderRadius: '6px', backgroundColor: '#F8FAFC', border: '1px dashed #CBD5E1', fontSize: '12px', color: '#475569' }}>
                This task is in your team's queue. Take it to start the on-site inspection.
              </div>
            )}

            {/* Status Card: Verification Submitted */}
            {selectedIsMine && selectedTask.status === 'field_verified' && (
              <div style={{
                backgroundColor: '#FEF3C7',
                borderRadius: '8px',
                border: '1px solid #FCD34D',
                padding: '16px',
                display: 'flex',
                flexDirection: 'column',
                gap: '8px'
              }}>
                <div style={{ fontSize: '13px', fontWeight: 800, color: '#92400E', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <CheckCircle2 size={18} color="#D97706" />
                  <span>On-Site Inspection Findings Submitted</span>
                </div>
                <div style={{ fontSize: '12px', color: '#78350F', lineHeight: '1.5' }}>
                  Your inspection report ({selectedTask.water_depth_cm ?? 55}cm water depth) has been recorded. The Control Room is reviewing evidence for road closure authorization.
                </div>
                <div style={{ fontSize: '12px', color: '#B45309', fontWeight: 700, marginTop: '4px' }}>
                  👉 You are free to take another task from the <strong>Team queue</strong>.
                </div>
              </div>
            )}

            {/* Status Card: Clearance Proposed */}
            {selectedIsMine && selectedTask.status === 'clearance_proposed' && (
              <div style={{
                backgroundColor: '#ECFDF5',
                borderRadius: '8px',
                border: '1px solid #A7F3D0',
                padding: '16px',
                display: 'flex',
                flexDirection: 'column',
                gap: '8px'
              }}>
                <div style={{ fontSize: '13px', fontWeight: 800, color: '#065F46', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <CheckCircle2 size={18} color="#059669" />
                  <span>Clearance & Dewatering Report Submitted</span>
                </div>
                <div style={{ fontSize: '12px', color: '#047857', lineHeight: '1.5' }}>
                  Drainage clearance proposal sent to Control Room for road reopening authorization.
                </div>
                <div style={{ fontSize: '12px', color: '#065F46', fontWeight: 700, marginTop: '4px' }}>
                  👉 You are free to take another task from the <strong>Team queue</strong>.
                </div>
              </div>
            )}

            {/* Form 1: On-site Verification (if not yet blocked or clearance proposed) */}
            {selectedIsMine && ['assigned', 'under_review', 'reported'].includes(selectedTask.status) && (
              <form onSubmit={handleVerifySubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                <div style={{ fontSize: '13px', fontWeight: 800, color: '#1E293B' }}>
                  Submit On-Site Inspection Findings:
                </div>

                {/* Water Depth Slider */}
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', fontWeight: 700, color: '#475569', marginBottom: '4px' }}>
                    <span>Measured Water Depth (cm):</span>
                    <span style={{ color: waterDepth > 35 ? '#B91C1C' : '#0B8B95', fontSize: '14px' }}>
                      {waterDepth} cm {waterDepth > 35 ? '(Impassable Depth)' : '(Passable with caution)'}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="100"
                    value={waterDepth}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setWaterDepth(val);
                      setIsImpassable(val >= 35);
                    }}
                    style={{ width: '100%', cursor: 'pointer' }}
                  />
                </div>

                {/* Impassable Toggle */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', backgroundColor: '#F8FAFC', padding: '10px 14px', borderRadius: '6px', border: '1px solid #E2E8F0' }}>
                  <input
                    type="checkbox"
                    id="impassable-check"
                    checked={isImpassable}
                    onChange={(e) => setIsImpassable(e.target.checked)}
                    style={{ width: '16px', height: '16px', cursor: 'pointer' }}
                  />
                  <label htmlFor="impassable-check" style={{ fontSize: '13px', fontWeight: 700, color: '#1E293B', cursor: 'pointer' }}>
                    Road is impassable for standard vehicular traffic (Recommend Hard Closure)
                  </label>
                </div>

                {/* Findings Text */}
                <div>
                  <label style={{ fontSize: '11px', fontWeight: 700, color: '#475569', display: 'block', marginBottom: '2px' }}>
                    Detailed Inspection Findings
                  </label>
                  <textarea
                    rows={3}
                    value={findings}
                    onChange={(e) => setFindings(e.target.value)}
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #CBD5E1', fontSize: '12px', backgroundColor: '#F8FAFC', resize: 'none' }}
                    required
                  />
                </div>

                {/* Evidence Note */}
                <div>
                  <label style={{ fontSize: '11px', fontWeight: 700, color: '#475569', display: 'block', marginBottom: '2px' }}>
                    Field Evidence Note / Gauge Calibration
                  </label>
                  <input
                    type="text"
                    value={evidenceNote}
                    onChange={(e) => setEvidenceNote(e.target.value)}
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #CBD5E1', fontSize: '12px', backgroundColor: '#F8FAFC' }}
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '8px',
                    padding: '10px',
                    borderRadius: '6px',
                    border: 'none',
                    backgroundColor: '#0B8B95',
                    color: '#FFFFFF',
                    fontWeight: 700,
                    fontSize: '13px',
                    cursor: isSubmitting ? 'not-allowed' : 'pointer',
                    boxShadow: '0 2px 4px rgba(11, 139, 149, 0.3)'
                  }}
                >
                  <Send size={15} />
                  {isSubmitting ? 'Submitting Verification...' : 'Submit Verified Finding to Admin'}
                </button>
              </form>
            )}

            {/* Form 2: Propose Clearance (if currently blocked) */}
            {selectedIsMine && selectedTask.is_blocked && (
              <form onSubmit={handleClearanceSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px', backgroundColor: '#F0FDF4', padding: '16px', borderRadius: '8px', border: '1px solid #BBF7D0' }}>
                <div style={{ fontSize: '13px', fontWeight: 800, color: '#166534' }}>
                  🌊 Dewatering Complete: Propose Clearance & Road Reopening
                </div>

                <div>
                  <label style={{ fontSize: '11px', fontWeight: 700, color: '#166534', display: 'block', marginBottom: '2px' }}>
                    Clearance Findings (Water Receded / Silt Cleared)
                  </label>
                  <textarea
                    rows={2}
                    value={clearanceFindings}
                    onChange={(e) => setClearanceFindings(e.target.value)}
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #86EFAC', fontSize: '12px', backgroundColor: '#FFFFFF', resize: 'none' }}
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '8px',
                    padding: '10px',
                    borderRadius: '6px',
                    border: 'none',
                    backgroundColor: '#16A34A',
                    color: '#FFFFFF',
                    fontWeight: 700,
                    fontSize: '13px',
                    cursor: isSubmitting ? 'not-allowed' : 'pointer',
                    boxShadow: '0 2px 4px rgba(22, 163, 74, 0.3)'
                  }}
                >
                  <Check size={16} />
                  {isSubmitting ? 'Submitting Clearance...' : 'Recommend Clearance to Control Room'}
                </button>
              </form>
            )}
          </div>
        ) : (
          <div style={{ backgroundColor: '#F8FAFC', padding: '24px', borderRadius: '10px', border: '1px dashed #CBD5E1', textAlign: 'center', color: '#64748B' }}>
            Select a task on the left to begin on-site field verification.
          </div>
        )}
      </div>
    </div>
  );
};
